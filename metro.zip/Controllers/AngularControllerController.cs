﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AngularJS.Controllers
{
    public class AngularControllerController : Controller
    {
        //
        // GET: /AngularController/

        public ActionResult Index()
        {
            return View();
        }

    }
}
