# Create Windows 8 Metro-like tiles with Bootstrap and AngularJS

Here is a simple AngularJS directive which, will allow you to create tiles together with Bootstrap.

read more on my blog: http://peter.grman.at/create-windows-8-metro-like-tiles-with-bootstrap-and-angularjs/